// Missile.h: interface for the CBomb class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MISSILE_H__EBBACAC6_1744_11D5_92C1_F7CF8823B376__INCLUDED_)
#define AFX_MISSILE_H__EBBACAC6_1744_11D5_92C1_F7CF8823B376__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "MyObject.h"

//��ҩ��С
#define BOMB_WIDTH	14
#define BOMB_HEIGHT 16

class CBomb : public CMyObject  
{
public:
	static void DeleteImage();
	static BOOL LoadImage();
	
	CRect GetRect() { return CRect(m_ptPos, CSize(BOMB_WIDTH, BOMB_HEIGHT)); }//���⺯���ľ���ʵ�֣��������ĵ������Լ�����Ĵ�С
	int GetType() { return m_nType; }
	CPoint GetPos() { return m_ptPos; }
	bool Draw(CDC* pDC, bool bPause);
	CBomb( int nVert, int nSpeed,int yVert);
	virtual ~CBomb();

private:
	int m_nType;
	int m_nSpeed;

	static CImageList m_Images;

};

#endif // !defined(AFX_MISSILE_H__EBBACAC6_1744_11D5_92C1_F7CF8823B376__INCLUDED_)

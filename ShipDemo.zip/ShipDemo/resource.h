//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ShipDemo.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_SHIPDETYPE                  129
#define IDB_EXPLOSION                   130
#define IDB_SHIP                        131
#define IDB_SUBMARINE                   132
#define IDB_BITMAP1                     140
#define IDB_BANG                        142
#define IDM_GAMEPAUSE                   32771

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        145
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
